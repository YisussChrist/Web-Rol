const formationSelect = document.getElementById("formationSelect");
const board = document.getElementById("board");
const slotsContainer = document.getElementById("slots");
const playersList = document.getElementById("playersList");
const searchInput = document.getElementById("searchInput");
const teamFilter = document.getElementById("teamFilter");
const positionFilter = document.getElementById("positionFilter");
const eventoInput = document.getElementById("eventoInput");
const equipoInput = document.getElementById("equipoInput");
const boardEventName = document.getElementById("boardEventName");
const boardTeamName = document.getElementById("boardTeamName");
const output = document.getElementById("output");
const btnCopiar = document.getElementById("btnCopiar");
const btnLimpiar = document.getElementById("btnLimpiar");

const playerDialog = document.getElementById("playerDialog");
const selectedSlotInfo = document.getElementById("selectedSlotInfo");
const dialogSearch = document.getElementById("dialogSearch");
const dialogPlayers = document.getElementById("dialogPlayers");
const dialogClose = document.getElementById("dialogClose");

let formaciones = {};
let personajes = [];
let currentFormation = "";
let placedPlayers = {};
let selectedSlotIndex = null;

init();

async function init() {
  const [formacionesRes, personajesRes] = await Promise.all([
    fetch("formaciones.json"),
    fetch("personajes.json")
  ]);

  formaciones = await formacionesRes.json();
  personajes = await personajesRes.json();

  fillFormationSelect();
  fillFilters();
  renderPlayers();
  changeFormation(Object.keys(formaciones)[0]);

  formationSelect.addEventListener("change", () => changeFormation(formationSelect.value));
  searchInput.addEventListener("input", renderPlayers);
  teamFilter.addEventListener("change", renderPlayers);
  positionFilter.addEventListener("change", renderPlayers);
  eventoInput.addEventListener("input", updateBoardTitle);
  equipoInput.addEventListener("input", updateBoardTitle);
  btnCopiar.addEventListener("click", copyTemplate);
  btnLimpiar.addEventListener("click", clearBoard);
  dialogSearch.addEventListener("input", renderDialogPlayers);
  dialogClose.addEventListener("click", () => playerDialog.close());
}

function fillFormationSelect() {
  formationSelect.innerHTML = Object.keys(formaciones)
    .map(name => `<option value="${name}">${name}</option>`)
    .join("");
}

function fillFilters() {
  const teams = [...new Set(personajes.map(p => p.equipo).filter(Boolean))].sort();
  const positions = [...new Set(personajes.map(p => p.posicion).filter(Boolean))].sort();

  teamFilter.innerHTML += teams.map(team => `<option value="${team}">${team}</option>`).join("");
  positionFilter.innerHTML += positions.map(pos => `<option value="${pos}">${pos}</option>`).join("");
}

function changeFormation(name) {
  currentFormation = name;
  formationSelect.value = name;
  placedPlayers = {};
  renderSlots();
  generateOutput();
}

function renderSlots() {
  const formation = formaciones[currentFormation];
  slotsContainer.innerHTML = "";

  formation.forEach((slot, index) => {
    const player = placedPlayers[index];
    const slotEl = document.createElement("div");
    slotEl.className = "slot";
    slotEl.style.left = `${slot.x}%`;
    slotEl.style.top = `${slot.y}%`;

    slotEl.innerHTML = `
      <div class="magnet ${player ? "" : "empty"}" data-index="${index}">
        ${player ? renderAvatar(player) : `<span class="slot-role">${slot.rol}</span>`}
        ${player?.dorsal ? `<span class="slot-number">${player.dorsal}</span>` : ""}
      </div>
      <div class="slot-role">${slot.rol}</div>
      <div class="slot-name">${player ? player.nombre : "Vacío"}</div>
    `;

    slotEl.querySelector(".magnet").addEventListener("click", () => openPlayerDialog(index));
    slotsContainer.appendChild(slotEl);
  });
}

function renderPlayers() {
  const filtered = getFilteredPlayers(searchInput.value, teamFilter.value, positionFilter.value);

  playersList.innerHTML = filtered.map((player, index) => `
    <div class="player-card" data-name="${escapeHtml(player.nombre)}">
      ${renderAvatar(player)}
      <div>
        <div class="player-name">${player.nombre}</div>
        <div class="player-meta">#${player.dorsal ?? "?"} · ${player.posicion ?? "?"} · ${player.equipo ?? "Sin equipo"}</div>
      </div>
    </div>
  `).join("");

  playersList.querySelectorAll(".player-card").forEach(card => {
    card.addEventListener("click", () => {
      const player = personajes.find(p => p.nombre === card.dataset.name);
      const firstEmptySlot = formaciones[currentFormation].findIndex((_, i) => !placedPlayers[i]);
      if (firstEmptySlot === -1) return;
      placedPlayers[firstEmptySlot] = player;
      renderSlots();
      generateOutput();
    });
  });
}

function openPlayerDialog(index) {
  selectedSlotIndex = index;
  const slot = formaciones[currentFormation][index];
  selectedSlotInfo.textContent = `Posición seleccionada: ${slot.rol}`;
  dialogSearch.value = "";
  renderDialogPlayers();
  playerDialog.showModal();
}

function renderDialogPlayers() {
  const slot = formaciones[currentFormation][selectedSlotIndex];
  const query = dialogSearch.value;

  const filtered = getFilteredPlayers(query, "", "").sort((a, b) => {
    const aMatch = a.posicion === slot.rol ? -1 : 0;
    const bMatch = b.posicion === slot.rol ? -1 : 0;
    return aMatch - bMatch || a.nombre.localeCompare(b.nombre);
  });

  dialogPlayers.innerHTML = filtered.map(player => `
    <div class="player-card" data-name="${escapeHtml(player.nombre)}">
      ${renderAvatar(player)}
      <div>
        <div class="player-name">${player.nombre}</div>
        <div class="player-meta">#${player.dorsal ?? "?"} · ${player.posicion ?? "?"} · ${player.equipo ?? "Sin equipo"}</div>
      </div>
    </div>
  `).join("");

  dialogPlayers.querySelectorAll(".player-card").forEach(card => {
    card.addEventListener("click", () => {
      const player = personajes.find(p => p.nombre === card.dataset.name);
      placedPlayers[selectedSlotIndex] = player;
      renderSlots();
      generateOutput();
      playerDialog.close();
    });
  });
}

function getFilteredPlayers(query, team, position) {
  const q = normalize(query);

  return personajes.filter(player => {
    const matchesQuery = !q || normalize(`${player.nombre} ${player.equipo} ${player.posicion}`).includes(q);
    const matchesTeam = !team || player.equipo === team;
    const matchesPosition = !position || player.posicion === position;
    return matchesQuery && matchesTeam && matchesPosition;
  });
}

function renderAvatar(player) {
  if (player.foto) {
    return `<img class="avatar" src="${player.foto}" alt="${player.nombre}" onerror="this.replaceWith(fallbackAvatar('${escapeHtml(player.nombre)}'))">`;
  }

  return `<div class="avatar avatar-fallback">${initials(player.nombre)}</div>`;
}

function fallbackAvatar(name) {
  const div = document.createElement("div");
  div.className = "avatar avatar-fallback";
  div.textContent = initials(name);
  return div;
}

function initials(name) {
  return name.split(" ").slice(0, 2).map(part => part[0]).join("").toUpperCase();
}

function updateBoardTitle() {
  boardEventName.textContent = eventoInput.value.trim() || "Evento sin nombre";
  boardTeamName.textContent = equipoInput.value.trim() || "Equipo sin definir";
  generateOutput();
}

function generateOutput() {
  const eventName = eventoInput.value.trim() || "Evento sin nombre";
  const teamName = equipoInput.value.trim() || "Equipo sin definir";

  const lines = [
    `⚽ ${eventName}`,
    `🏟️ Equipo: ${teamName}`,
    `📋 Formación: ${currentFormation}`,
    "",
    "━━━━━━━━━━━━━━━━━━━━",
    ""
  ];

  formaciones[currentFormation]?.forEach((slot, index) => {
    const player = placedPlayers[index];
    lines.push(`${slot.rol}: ${player ? `#${player.dorsal ?? "?"} ${player.nombre}` : "Vacío"}`);
  });

  output.value = lines.join("\n");
}

async function copyTemplate() {
  generateOutput();
  await navigator.clipboard.writeText(output.value);
  btnCopiar.textContent = "Copiado ✅";
  setTimeout(() => btnCopiar.textContent = "Copiar plantilla", 1400);
}

function clearBoard() {
  placedPlayers = {};
  renderSlots();
  generateOutput();
}

function normalize(text) {
  return String(text ?? "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function escapeHtml(text) {
  return String(text ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}
